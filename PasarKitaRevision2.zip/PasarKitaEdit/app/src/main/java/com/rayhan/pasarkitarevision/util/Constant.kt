package com.rayhan.pasarkitarevision.util

object Constant {
    interface OnItemClickListener {
        fun onItemClick(productId: Int)
    }
}
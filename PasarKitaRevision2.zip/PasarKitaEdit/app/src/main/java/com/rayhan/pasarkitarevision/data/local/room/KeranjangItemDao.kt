package com.rayhan.pasarkitarevision.data.local.room

interface KeranjangItemDao {
}
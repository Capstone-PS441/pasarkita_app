package com.rayhan.pasarkitarevision.data.local.room

annotation class KeranjangItemRoomDatabase()

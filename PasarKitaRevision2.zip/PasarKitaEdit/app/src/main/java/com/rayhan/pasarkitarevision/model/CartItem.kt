package com.rayhan.pasarkitarevision.model

data class CartItem(
    val image: String,
    val name: String,
    val satuan: String,
    val price: Int,

)
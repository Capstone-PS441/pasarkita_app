package com.rayhan.pasarkitarevision.model

data class CategoryItem(
    val name: String,
    val imageResId: Int
)
